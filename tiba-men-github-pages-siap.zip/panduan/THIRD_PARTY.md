# Teknologi dan sumber aset

## MediaPipe Tasks Vision

- Pakej: `@mediapipe/tasks-vision`, versi tepat **1.1.0**; integriti npm dikunci dalam `package-lock.json`.
- Asal: [pakej npm MediaPipe](https://www.npmjs.com/package/@mediapipe/tasks-vision), [repositori Google AI Edge](https://github.com/google-ai-edge/mediapipe).
- Fail yang dibundel tanpa perubahan: `dist/vendor/mediapipe/vision_bundle.mjs` serta enam fail loader/WASM dalam subfolder `wasm`.
- Lesen Apache 2.0 disertakan sebagai `dist/vendor/mediapipe/LICENSE`, daripada [lesen rasmi](https://github.com/google-ai-edge/mediapipe/blob/master/LICENSE).
- Loader module digunakan untuk worker ESM. Loader biasa dan no-SIMD turut disertakan daripada pakej yang sama, tetapi laluan modul yang diuji memerlukan pelayar dengan WebAssembly SIMD/module worker yang serasi. Peranti tidak serasi menerima mesej kegagalan dan boleh bermain dengan tetikus.

## Model tangan

- Hand Landmarker, float16, versi model **1**, fail `dist/models/hand_landmarker.task`.
- Sumber: [Google MediaPipe model bundle](https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task).
- Dokumentasi: [Hand Landmarker overview/model](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker), [implementasi web](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/web_js).
- Model disertakan setempat untuk pemprosesan bingkai pada peranti, menggunakan CPU. Tiada pemindahan bingkai kamera ke API inferens luaran.

## Hash semakan SHA-256

| Fail | SHA-256 |
|---|---|
| `models/hand_landmarker.task` | `fbc2a30080c3c557093b5ddfc334698132eb341044ccee322ccf8bcf3607cde1` |
| `vendor/mediapipe/vision_bundle.mjs` | `9d5fc9ef74b22329cf9aa88dc543956d192b8c254210b187271614713eb5b10c` |
| `vendor/mediapipe/wasm/vision_wasm_module_internal.wasm` | `ee03b14a878e6c3c053a1bfa62e166dc45244be54dc0bbe61c578f710b771f6a` |

Semua laluan dalam jadual adalah relatif kepada `dist/`. Semak hash selepas pengekstrakan jika mengesyaki fail tidak lengkap.

## Visual, fon dan audio

Ilustrasi MIM, avatar, istana, ikon, kad dan enam adegan ialah SVG/Canvas yang ditulis dalam kod projek. Tiada foto murid atau bahan stok diperlukan. Ilustrasi versi pertama dikekalkan bagi bank kata dan versi arkib. Fon menggunakan fon sistem peranti; tiada permintaan fon luar.

Bunyi ringkas dijana menggunakan Web Audio. Arahan pertuturan menggunakan Web Speech API hanya jika suara Bahasa Melayu tersedia. Ketersediaan suara serta pelaksanaannya ditentukan oleh pelayar/sistem pengendalian.

## Aset ujian sahaja

`tests/tracking.cjs` memuat turun [pointing_up.jpg daripada aset MediaPipe](https://storage.googleapis.com/mediapipe-assets/pointing_up.jpg) ke `.local/` jika belum ada. Foto ini digunakan dalam [ujian rasmi Hand Landmarker](https://github.com/google-ai-edge/mediapipe/blob/master/mediapipe/tasks/python/test/vision/hand_landmarker_test.py). Foto tidak diterbitkan dalam `dist/` atau dimuatkan oleh permainan. Aliran video ujian dibina daripada foto ini, bukan kamera manusia secara langsung.

Playwright **1.51.1** ialah dependency pembangunan untuk ujian Microsoft Edge. Node.js digunakan sebagai pelayan localhost, bukan dependency pelayar.
