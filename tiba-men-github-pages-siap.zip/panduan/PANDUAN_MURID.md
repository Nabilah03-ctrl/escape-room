# Jom bantu MIM!

1. Pilih **Imbas & Kenal**. Lihat perkataan dan gambar. Cuba **Detektif Imbuhan**.
2. Isi nama dan kelas. Minta guru membantu jika perlu. Pilih robot, kucing atau angkasawan.
3. Pilih tetikus atau gerakan tangan. Buat **Latihan kawalan** dahulu.
4. Masuk ke bilik yang bercahaya. Baca arahan MIM atau pilih **Dengar soalan**.
5. Pilih kad. Letakkan pada ruang dengan label yang sama. Lengkapkan semua ruang.
6. Pilih **Semak jawapan**. Jika belum tepat, baca petunjuk dan cuba lagi. Kamu boleh mengulang.
7. Selesaikan empat cabaran untuk mendapat satu kunci. Kumpulkan enam kunci dan buka peti bahasa!

## Pilih kawalan yang selesa

**Tetikus:** klik kad, kemudian klik ruang. Kamu juga boleh menekan dan menyeret kad ke ruang. Lepaskan butang tetikus apabila kad sampai.

**Sentuhan:** sentuh kad, kemudian sentuh ruang.

**Papan kekunci:** gunakan `Tab` untuk bergerak. Tekan `Enter` atau `Space` untuk memilih.

**Tangan:** pilih mod tangan dan **Aktifkan kamera**. Tunjukkan satu tangan. Buka cubitan dahulu. Gerakkan jari telunjuk untuk menggerakkan cahaya. Cubit ibu jari dan telunjuk untuk memegang kad. Gerakkan ke ruang. Buka cubitan untuk melepaskan.

**Tahan untuk pilih:** jika cubitan sukar, minta guru memilih kawalan ini. Tahan cahaya pada kad sehingga gelang penuh. Kemudian tahan pada ruang. Keluar dari sasaran jika mahu membatalkan pilihan. Gunakan **Atas/Bawah** pada dok untuk menatal.

Jika tangan tidak dikesan, bertenang dan tunjukkan semula tangan. Pilih **Sambung** apabila bersedia. Kamu juga boleh menukar kepada tetikus. Kad yang tersasar tidak dikira sebagai jawapan salah.

## Kamu boleh berehat

Pilih **Henti seketika**. Masa berhenti. Pilih **Sambung** apabila bersedia. Masa bukan perlumbaan dan tidak menentukan kunci atau lencana.

Pilih **Petunjuk** untuk bantuan bahasa. Pilih **Bantuan kawalan** untuk bantuan memindahkan kad. Guru boleh membesarkan teks, mengurangkan hiasan atau mematikan bunyi dalam **Tetapan**.

Selepas tamat, cetak kad misi bersama guru. Kemudian bina dua ayat sendiri menggunakan **Papan Ayat meN-** dan kad maujud.
