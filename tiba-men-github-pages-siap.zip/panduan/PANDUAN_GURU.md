# Panduan penggunaan guru

## Persediaan

Jalankan melalui localhost atau HTTPS seperti dalam README. Gunakan komputer berorientasi landskap, skrin yang jelas dan ruang duduk yang selesa. Mulakan dengan mod tetikus untuk mengenali aliran. Untuk tangan, cuba kamera/peranti sasaran dahulu: cahaya sekata, satu tangan dalam bingkai dan kedudukan yang tidak memenatkan. Jangan mewajibkan gerakan pantas, dua tangan atau cubitan bagi murid yang memerlukan alternatif.

Pilihan kawalan memberikan tangan kiri/kanan/mana-mana, kawasan gerakan 45–100%, tahan 0.6–3 saat dan pratonton yang boleh disembunyikan. Nilai penyesuaian bersama murid menggunakan latihan tiga sasaran, pilihan objek dan pemindahan kad. Kamera hanya bermula selepas **Aktifkan kamera**. Jika gagal, gunakan tetikus tanpa menandakan kesalahan bahasa.

**Penting untuk pelaksanaan:** versi ini telah diuji secara automatik dan melalui inferens foto/video terkawal. Ujian manusia secara langsung dengan kamera fizikal belum dibuat. Laksanakan semakan kamera sebenar dan kebolehgunaan bersama guru sebelum sesi murid.

## Objektif dan penjajaran

Penjajaran yang ditetapkan dalam brief: Bahasa Melayu SK Tahun 2, SK 5.2 dan SP 5.2.1(iii), pembentukan kata berimbuhan awalan mengikut konteks. Kod standard ini digunakan daripada brief; projek tidak mendakwa audit DSKP rasmi yang berasingan.

Murid mengenal keluarga meN-, memadankan kata dasar dengan hasil, menggunakan perbuatan dalam konteks, membetulkan kesalahan, memilih tindakan dan alasan serta merancang dua tindakan mengikut tujuan. Aras mencipta diteruskan melalui dua ayat sendiri menggunakan bahan maujud. Peringkat permainan bukan TP PBD.

Mulakan dengan **membaca** dan **melukis**. Terangkan bahawa meN- ialah lambang keluarga; huruf N tidak ditulis secara literal. Gunakan bank semakan untuk menulis, menyapu, mengutip dan memukul; jangan mengajar cantuman mentulis atau menggambarkan pengguguran huruf sebagai hukum tanpa pengecualian.

## Contoh sesi 60 minit

| Aktiviti | Minit | Bentuk |
|---|---:|---|
| Imbas & Kenal | 7 | Digital |
| Detektif Imbuhan | 5 | Digital |
| Escape room | 30 | Digital |
| Manipulasi kad awalan, kata dasar dan cip huruf | 6 | Maujud |
| Membina dua ayat sendiri | 12 | Maujud |

42 minit digital (70%) dan 18 minit maujud (30%). Ini contoh agihan PdP, bukan pemasa had. Pecahkan kepada beberapa sesi mengikut keperluan dan catat masa sebenar. Semua 24 cabaran serta semakan escape room adalah digital.

## Semakan dan bimbingan

Bilik 1–3 membina asas dan aplikasi. Bilik 4 memerlukan perkataan serta sebab; Bilik 5 tindakan serta alasan; Bilik 6 dua tindakan dalam urutan serta sebab. Murid mesti melengkapkan semua komponen sebelum semakan direkodkan. Jawapan separa tidak menghasilkan kesalahan bahasa atau ganjaran.

Dalam mod bimbingan, setiap komponen mempunyai dua pilihan. Kedua-dua tindakan masih perlu disusun dan alasan masih perlu dipilih. Kedudukan pilihan berubah mengikut sesi/soalan. Selepas tiga semakan tidak tepat, sistem turut mengurangkan pilihan dan merekodkan percubaan berikutnya sebagai berbimbing.

Tiga petunjuk memperincikan maklumat penting, hubungan bahasa/tujuan dan contoh berkaitan. Petunjuk yang mendedahkan contoh jawapan tetap dikira sebagai bantuan; penyelesaian selepas itu tidak dilabel penguasaan kendiri. Salah lepas kad atau tracking hilang bukan semakan bahasa.

## Membaca rekod

**Semakan pertama betul** bermaksud jawapan lengkap pertama tepat; ia mungkin dibuat selepas petunjuk. **Pertama betul tanpa petunjuk, mod biasa** ialah subset yang lebih ketat. Mod bimbingan, petunjuk sebelum semakan dan jawapan setiap komponen boleh diperiksa dalam jejak semakan guru.

Percubaan semula ialah jumlah semakan selepas semakan pertama bagi setiap cabaran. Petunjuk bahasa, permintaan bantuan kawalan, kehilangan tracking dan catatan bantuan guru di luar sistem dilaporkan secara berasingan. Masa ialah masa aktif menyelesaikan cabaran, bukan ukuran kepintaran, markah atau TP.

Guru boleh melihat ringkasan semasa jeda. Peringkat belum dimulakan tidak mempunyai masa penyelesaian; peringkat belum selesai dilabel **Masa setakat ini**. Kunci/lencana diperoleh selepas empat cabaran selesai; ganjaran sama diberikan walaupun murid menggunakan bantuan.

Panel rekod menyediakan carian, pilihan sesi, CSV ringkasan/percubaan, cetakan, butiran dan catatan bantuan luar. **Semak semua 24 cabaran** menggunakan sesi sementara: tiada pemasa dan tiada rekod pencapaian murid. Latihan ulangan bilik tidak menindih rekod asal.

Rekod hanya berada dalam pelayar/peranti/origin yang sama. Tiada akaun guru atau penyegerakan pelayan. Cetak/eksport salinan sebelum memadam data atau menukar peranti. Memulakan murid baharu menghasilkan sesi kosong; rekod lama kekal dalam panel selagi storan tidak dipadam. Versi pertama permainan dan storannya kekal melalui pautan **Misi Enam Pintu Imbuhan** dalam panel guru.

## Bahan maujud

Buka **Bahan maujud untuk dicetak**, kemudian **Cetak semua bahan**. Halaman A4 mengandungi enam awalan, sepuluh kata dasar/hasil, cip p/t/k/s, kad pelaku, objek/keterangan, situasi, kad kosong, papan bina kata dan dua papan ayat. Lekat pada kadbod dengan Velcro atau magnet yang sesuai.

Situasi susulan: **Kelas akan menerima tetamu. Lantai berdebu dan papan pameran kosong. Bina dua ayat tentang tindakan yang membantu.**

Contoh untuk guru: “Saya menyapu lantai.” dan “Saya melukis bunga untuk papan pameran.” Terima idea lain yang tepat, bermakna dan sesuai. Murid boleh menyusun kad, membaca, menunjuk atau menjawab secara lisan. Aktiviti ini tidak menjadi syarat membuka pintu digital.

## Pentaksiran

Gunakan item setara sebelum/selepas, bukan mengulangi semua pilihan yang telah dihafal. Contoh pengecaman awal membaca dan item setara membawa selepas sesi. Beri satu situasi baharu dan minta murid menerangkan pilihan dengan kata sendiri.

Untuk ayat maujud, catat ketepatan bentuk meN-, makna ayat dan kesesuaian tindakan. Bezakan bantuan membacakan arahan, bantuan memilih dan bantuan motor. Laporan permainan menyokong pemerhatian guru; ia tidak menetapkan Tahap Penguasaan PBD.

## Jika ada masalah

| Keadaan | Tindakan |
|---|---|
| Kamera tiada/ditolak | Pilih tetikus. Semak izin tapak melalui tetapan pelayar jika mahu mencuba semula. |
| Model gagal | Pastikan semua folder vendor/model diekstrak, gunakan localhost/HTTPS dan pelayar moden. Tetikus tetap tersedia. |
| Penunjuk sukar sampai tepi | Kurangkan kawasan gerakan dan ulang latihan sasaran. |
| Cubitan sukar | Gunakan tahan untuk pilih atau klik kad kemudian ruang. |
| Tangan hilang | Pegangan dibatalkan. Tunjukkan semula dan pilih Sambung; tiada semakan automatik. |
| Tiada suara Melayu | Baca teks atau minta guru membacakan arahan; suara bahasa lain tidak dipaksakan. |
| Amaran storan | Cetak/eksport rekod yang masih tersedia; gunakan pelayar yang membenarkan storan. |

Selepas sesi, matikan kamera dan tutup panel rekod sebelum menyerahkan peranti kepada orang lain.
