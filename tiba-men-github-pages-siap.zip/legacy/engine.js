(function (T) {
  'use strict';
  T.STORAGE_KEY = 'tiba-men-v1';
  T.defaults = { largeText:false, contrast:false, reducedMotion:false, mute:false, simple:false, support:'progressive', thresholds:[12,18,22] };
  T.newDatabase = () => ({version:1, sessions:[], activeId:null, settings:{...T.defaults}});
  T.newRecord = () => ({attempts:[], hints:0, mastered:false, firstCorrect:false, duration:0});
  T.newSession = (name, studentClass) => ({
    sessionId:typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36)+Math.random().toString(36).slice(2),
    studentName:name.trim().slice(0,80), studentClass:studentClass.trim().slice(0,40),
    startedAt:new Date().toISOString(), completedAt:null, completionStatus:'in-progress',
    currentDoor:1, currentQuestion:1, pausedState:true, totalActiveDuration:0,
    levelDurations:Array(6).fill(0), records:Object.fromEntries(T.questions.map(q=>[q.id,T.newRecord()]))
  });
  T.stats = (session, door) => {
    const qs=T.questions.filter(q=>!door||q.door===door), rs=qs.map(q=>session.records[q.id]);
    return {mastered:rs.filter(r=>r.mastered).length, score:rs.filter(r=>r.firstCorrect).length,
      retries:rs.reduce((n,r)=>n+Math.max(0,r.attempts.length-1),0), hints:rs.reduce((n,r)=>n+r.hints,0),
      attempted:rs.filter(r=>r.attempts.length).length, duration:door?session.levelDurations[door-1]:session.totalActiveDuration,
      doors:T.doors.filter(d=>T.questions.filter(q=>q.door===d.id).every(q=>session.records[q.id].mastered)).length};
  };
  T.isUnlocked = (s,d) => Number.isInteger(d)&&d>=1&&d<=6&&(d===1||T.questions.filter(q=>q.door<d).every(q=>s.records[q.id].mastered));
  T.currentUnsolved = s => T.questions.find(q=>!s.records[q.id].mastered);
  T.isCorrect = (q,value) => q.type==='sequence' ? Array.isArray(value)&&value.length===q.sequence.length&&q.sequence.every((v,i)=>value[i]===v) : value===q.answer;
  T.submit = (s,id,value) => {
    const q=T.questions.find(q=>q.id===id);
    if(!q||!T.isUnlocked(s,q.door)) return {accepted:false};
    const r=s.records[id];
    if(r.mastered) return {accepted:false};
    if(q.type==='sequence' ? !Array.isArray(value)||value.length!==2||new Set(value).size!==2||value.some(v=>!Number.isInteger(v)||v<0||v>=q.cards.length) : !Number.isInteger(value)||value<0||value>=q.options.length) return {accepted:false};
    const correct=T.isCorrect(q,value);
    if(r.attempts.length===0) r.firstCorrect=correct;
    r.attempts.push({value:Array.isArray(value)?[...value]:value,correct,at:new Date().toISOString()});
    r.mastered=correct;
    const next=T.currentUnsolved(s);
    s.currentQuestion=next?.id||24; s.currentDoor=next?.door||6;
    if(!next){s.completionStatus='complete';s.completedAt=new Date().toISOString();s.pausedState=true;}
    return {accepted:true,correct,record:r};
  };
  T.addHint = (s,id) => {const r=s.records[id];if(!r||r.mastered||r.hints>=2)return false;r.hints++;return true;};
  T.addTime = (s,id,ms) => {
    if(!Number.isFinite(ms)||ms<=0)return;
    const q=T.questions.find(q=>q.id===id);
    if(!q||s.records[id].mastered||!T.isUnlocked(s,q.door))return;
    s.records[id].duration+=ms;s.levelDurations[q.door-1]+=ms;s.totalActiveDuration+=ms;
  };
  T.formatTime = ms => {const t=Math.floor(Math.max(0,ms)/1000);return [Math.floor(t/3600),Math.floor(t/60)%60,t%60].map(n=>String(n).padStart(2,'0')).join(':');};
  T.category = (score,thresholds=T.defaults.thresholds) => score<thresholds[0]?'Memerlukan bimbingan lanjut':score<thresholds[1]?'Sedang berkembang':score<thresholds[2]?'Baik':'Sangat baik';
  T.readDatabase = raw => {
    if(!raw)return T.newDatabase();
    const db=JSON.parse(raw);
    if(db.version!==1||!Array.isArray(db.sessions))throw new Error('Format rekod tidak disokong.');
    for(const s of db.sessions){
      if(typeof s.sessionId!=='string'||typeof s.studentName!=='string'||typeof s.studentClass!=='string'||!Array.isArray(s.levelDurations)||s.levelDurations.length!==6||s.levelDurations.some(n=>!Number.isFinite(n)||n<0)||!Number.isFinite(s.totalActiveDuration)||s.totalActiveDuration<0)throw new Error('Rekod sesi tidak lengkap.');
      for(const q of T.questions){const r=s.records?.[q.id];if(!r||!Array.isArray(r.attempts)||!Number.isInteger(r.hints)||r.hints<0||r.hints>2||typeof r.mastered!=='boolean'||typeof r.firstCorrect!=='boolean'||!Number.isFinite(r.duration)||r.duration<0)throw new Error('Rekod cabaran tidak lengkap.');}
      s.pausedState=true;
    }
    db.settings={...T.defaults,...db.settings};
    if(!Array.isArray(db.settings.thresholds)||db.settings.thresholds.length!==3||db.settings.thresholds.some((n,i,a)=>!Number.isInteger(n)||n<1||n>24||(i&&n<=a[i-1])))db.settings.thresholds=[...T.defaults.thresholds];
    if(!db.sessions.some(s=>s.sessionId===db.activeId))db.activeId=null;
    return db;
  };
  T.csvCell = value => {let str=String(value??'');if(/^[\s]*[=+@-]/.test(str))str="'"+str;return '"'+str.replace(/"/g,'""')+'"';};
  T.toCSV = sessions => {
    const header=['ID sesi','Nama murid','Kelas','Tarikh mula','Tarikh tamat','Pintu selesai','Skor awal /24','Cabaran dikuasai /24','Percubaan semula','Petunjuk','Jumlah masa aktif','Status',...T.doors.map(d=>'Masa Pintu '+d.id)];
    const rows=sessions.map(s=>{const z=T.stats(s);return [s.sessionId,s.studentName,s.studentClass,s.startedAt,s.completedAt,z.doors,z.score,z.mastered,z.retries,z.hints,T.formatTime(z.duration),s.completionStatus==='complete'?'Tamat':'Belum tamat',...s.levelDurations.map(T.formatTime)];});
    return '\uFEFF'+[header,...rows].map(r=>r.map(T.csvCell).join(',')).join('\r\n');
  };
  T.detailCSV = sessions => {
    const rows=[['ID sesi','Nama','Kelas','Pintu','Soalan','Arahan','Percubaan','Jawapan dipilih','Betul','Petunjuk digunakan','Masa soalan']];
    sessions.forEach(s=>T.questions.forEach(q=>s.records[q.id].attempts.forEach((a,i)=>rows.push([s.sessionId,s.studentName,s.studentClass,q.door,q.id,q.instruction,i+1,Array.isArray(a.value)?a.value.map(v=>q.cards[v]).join(' → '):q.options[a.value],a.correct?'Ya':'Tidak',s.records[q.id].hints,T.formatTime(s.records[q.id].duration)]))));
    return '\uFEFF'+rows.map(r=>r.map(T.csvCell).join(',')).join('\r\n');
  };
})(window.Tiba);
